CREATE FUNCTION on_class_insert()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE   
  ID INTEGER;   
  A INTEGER;   
  DATE_OF_END_FLAG INTEGER;   
  BIRTH_FLAG INTEGER; 
BEGIN   
  IF NEW.CLASS_ID IS NULL THEN     
    ID = (SELECT MAX(CLASS_ID) FROM CLASS);     
    IF ID IS NULL THEN       
      ID = 0; 
    ELSE ID = ID + 1;     
    END IF;     
    NEW.CLASS_ID = ID;   
  END IF; 
 
    DATE_OF_END_FLAG = (SELECT COUNT(*) FROM TUTOR WHERE TUTOR.TUTOR_ID=NEW.TUTOR_ID                                           AND TUTOR.DATE_OF_END IS NOT NULL);     IF (DATE_OF_END_FLAG <> 0) THEN       A = (SELECT COUNT(*) FROM TUTOR           WHERE TUTOR.TUTOR_ID=NEW.TUTOR_ID                 AND (TUTOR.DATE_OF_BEGINNING <= NEW.DATE_TIME )           AND (TUTOR.DATE_OF_END >= NEW.DATE_TIME));       IF (A = 0) THEN RAISE 'Некорректная дата урока';       END IF;     ELSE A = (SELECT COUNT(*) FROM TUTOR WHERE TUTOR.TUTOR_ID=NEW.TUTOR_ID                                               AND TUTOR.DATE_OF_BEGINNING<=NEW.DATE_TIME);       IF (A = 0) THEN RAISE 'Некорректная дата урока';       END IF;     END IF; 
 
  RETURN NEW; 
END;
$$;

