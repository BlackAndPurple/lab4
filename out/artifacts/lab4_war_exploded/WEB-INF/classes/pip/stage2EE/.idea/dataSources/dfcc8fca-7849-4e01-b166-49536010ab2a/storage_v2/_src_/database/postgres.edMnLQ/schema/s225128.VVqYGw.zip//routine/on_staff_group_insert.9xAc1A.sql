CREATE FUNCTION on_staff_group_insert()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
  ID INTEGER;
  A INTEGER;
  BIRTH_COUNT INTEGER;
BEGIN
  
  IF NEW.date_of_beginning IS NULL THEN
    NEW.date_of_beginning=CURRENT_DATE;
  END IF;
  
  RETURN NEW;
END;
$$;

