CREATE FUNCTION people_inserterer(integer)
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
 N alias for $1;
 rand INTEGER default 0 ;
 length integer;
 i INTEGER DEFAULT 1;
 count integer default 0;
 NAMES text[] := '{Addison,Adrian,Alex,Alexis,Andy,Aubrey,Avery,Bailey,Blaine,Blair,Brice,Cameron,Carson,Cary,Casey,' ||
                  'Cody,Corey,Dane,Devon,Drew,Dustin,Emerson,Erin,Evan,Fabian,Florian,Francis,Hadley,Haiden,Harley,Hayden,' ||
                  'Israel,Jade,Jaden,Jan,Jerry,Jordan,Jude,Julian,Kendall,Kennedy,Kerry,Lane,Lee,Lonnie,MacKenzie,Madison,' ||
                  'Mason,Noel,Orion,Perry,Quinn,Raphael,Ravenel,Reese,Riley,Robin,Ryan,Shane,Shelby,Spencer,Sydney,' ||
                  'Taylor,Terry,Tony,Tory,Tyler,Wynne,Zane}';
  SURNAMES text[] :='{Giacalone,Greenlaw,Babetski,Westlock,Ruiz,Addison,Blackwolf,Ravenhorst,Levine,Tessington,' ||
                    'Wing,Oliver,Younger,Patel,Rance,Pennington,Erickson,Burnand,Owen,Cassadine,Adair,Jefferies,Fenton,' ||
                    'Scarebrook,Wise,Melville,Bobbin,Willis,Patterson,Edgeworth,Gagwilde,Nadler,Decker,Tiffey,Furmage,' ||
                    'Beck,Pittman,Cross,Roberts,Curry,Taylor,Manning,Clark,Pearson,Freeman,Harvey,Russell,Evans,' ||
                    'Henderson,Howard,Nelson,Carter,Williams,Coleman,Rivera,Cooper,Anderson,Simmons,Phillips,King,Campbell,' ||
                    'Barnes,Bennett,Lewis,Foster,Reed,Allen,Smith,Sanders}';
 NAME text := NULL;
  MIDDLE_NAME text := NULL;
  SURNAME TEXT := NULL;
  SEX BOOL := FALSE;
  BIRTHDAY DATE;

  BEGIN
 for i in 1..N loop
  RAND := floor(random()*69)+1;
 NAME:=NAMES[RAND];
  rand := floor(random()*69)+1;
  MIDDLE_NAME:=NAMES[rand];
  RAND := floor(random()*69)+1;
  SURNAME:=SURNAMES[RAND];
  RAND := floor(random()*2)+0;
  IF RAND = 1 THEN
    SEX := TRUE;
    ELSE SEX:=FALSE;
  END IF;
  BIRTHDAY =( select DATE '1960-01-01' +
       random() * (TIMESTAMP '2014-01-01' -
                   TIMESTAMP '1960-01-01'));
  insert into s225128.PEOPLE(NAME, MIDDLE_NAME, SURNAME, SEX, DATE_OF_BIRTH) values(name, MIDDLE_NAME, SURNAME, SEX, BIRTHDAY);
  NAME := '';
  SEX:= NULL;


 end loop;

  END;
$$;

