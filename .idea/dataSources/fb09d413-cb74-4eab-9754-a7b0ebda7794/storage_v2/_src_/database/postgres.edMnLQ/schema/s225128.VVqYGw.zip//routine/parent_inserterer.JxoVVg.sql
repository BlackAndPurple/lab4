CREATE FUNCTION parent_inserterer()
  RETURNS void
LANGUAGE plpgsql
AS $$
DECLARE
   BEGIN
  insert into s225128.PARENT(PERSON_ID) SELECT PERSON_ID FROM s225128.people WHERE date_of_birth <= '1990-01-01' and person_id <= 250;

     
   END;
$$;

